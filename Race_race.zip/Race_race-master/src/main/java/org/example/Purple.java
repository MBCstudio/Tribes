package org.example;

public class Purple extends Tribe {
    Purple(){
        this.physical_strength = 2;
        this.agility = 5;
        this.iq = 3;
        this.endurance = 2;
        this.multiply_speed_x = 2;
        this.multiply_speed_y = 1;
        this.name = "Purple";
    }
}
