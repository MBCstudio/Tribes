package org.example;

public class White extends Tribe {
    White(){
        this.physical_strength = 3;
        this.agility = 1;
        this.iq = 4;
        this.endurance = 4;
        this.multiply_speed_x = 1;
        this.multiply_speed_y = 1;
        this.name = "White";
    }
}
