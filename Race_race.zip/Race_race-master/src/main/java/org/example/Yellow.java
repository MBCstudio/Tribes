package org.example;

public class Yellow extends Tribe {
    Yellow(){
        this.physical_strength = 4;
        this.agility = 2;
        this.iq = 5;
        this.endurance = 1;
        this.multiply_speed_x = 1;
        this.multiply_speed_y = 3;
        this.name = "Yellow";
    }
}
