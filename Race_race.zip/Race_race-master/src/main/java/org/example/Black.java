package org.example;

public class Black extends Tribe {
    Black(){
        this.physical_strength = 5;
        this.iq = 1;
        this.agility = 3;
        this.endurance = 3;
        this.multiply_speed_x=2;
        this.multiply_speed_y=2;
        this.name = "Black";
    }
}
