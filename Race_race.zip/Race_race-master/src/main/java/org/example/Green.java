package org.example;

public class Green extends Tribe {
    Green(){
        this.physical_strength = 1;
        this.agility = 4;
        this.iq = 2;
        this.endurance = 5;
        this.multiply_speed_x = 1;
        this.multiply_speed_y = 2;
        this.name = "Green";
    }
}
